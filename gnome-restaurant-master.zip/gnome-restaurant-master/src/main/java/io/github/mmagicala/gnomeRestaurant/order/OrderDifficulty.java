package io.github.mmagicala.gnomeRestaurant.order;

public enum OrderDifficulty
{
	EASY, HARD
}
