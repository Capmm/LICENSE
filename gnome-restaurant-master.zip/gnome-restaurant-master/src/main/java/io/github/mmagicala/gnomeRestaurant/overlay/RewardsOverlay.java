package io.github.mmagicala.gnomeRestaurant.overlay;

public class RewardsOverlay
{
}
